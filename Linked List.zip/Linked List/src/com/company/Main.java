package com.company;
import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		Linked_List obj = new Linked_List();
		char response = 'y';
		int to_add;
	while(response == 'y')
	{
		System.out.println("Please enter a number to add to the list:");
		to_add = read.nextInt();
		read.nextLine();
		obj.add_at_beginning(to_add);
		//obj.add(to_add);
		//obj.add_with_node(to_add);
		System.out.println("Would you like to add another?");
		response = read.next().charAt(0);
		read.nextLine();
	}
	    obj.display();
		//Linked_List obj2 = new Linked_List(obj);
		Linked_List obj2 = new Linked_List();
		int copied = obj2.copy_with_node(obj);
		System.out.println("Total copied: " + copied);
		obj2.display();
		int total_matching = obj.total_matching(7);
		System.out.println("Total matching:" + total_matching);
		int total_reversed = obj.reverse_list();
		obj.display();
		System.out.println("\n\nTotal reversed: " + total_reversed);
    }
}
