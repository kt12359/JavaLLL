package com.company;

public class Node {
    private int data;
    private Node next;

    Node(int to_add)
    {
        this.data = to_add;
        this.next = null;
    }

    Node(Node to_copy)
    {
        this.data = to_copy.data;
        this.next = null;
    }

    Node get_next()
    {
        return this.next;
    }

    void set_next(Node some_node)
    {
        this.next = some_node;
    }

    boolean is_match(int to_compare)
    {
        if(to_compare == data)
            return true;
        return false;
    }

    void add(int to_add)
    {
        if(this.next == null)
        {
            this.next = new Node(to_add);
            return;
        }
        this.next.add(to_add);
    }

    void display()
    {
        System.out.println(this.data);
    }

    int copy_with_node(Node source)
    {
        if(source == null)
            return 0;
        if(this.next == null)
            this.next = new Node(source);
        return this.next.copy_with_node(source.next) + 1;
    }

}
