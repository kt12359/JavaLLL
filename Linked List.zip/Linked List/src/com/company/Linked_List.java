package com.company;

public class Linked_List {

    private Node head = null;

    Linked_List(Linked_List to_copy) {
        this.head = copy_list(this.head, to_copy.head);
    }

    Linked_List() {
        this.head = null;
    }

    void add_with_node(int to_add) {
        if (this.head == null) {
            head = new Node(to_add);
            return;
        }
        this.head.add(to_add);

    }

    void add(int to_add) {
        if (head == null) {
            head = new Node(to_add);
        } else
            head.set_next(add(head.get_next(), to_add));
    }

    Node add(Node head, int to_add) {
        if (head == null) {
            this.head = new Node(to_add);
            return this.head;
        }
        head.set_next(add(head.get_next(), to_add));
        return head;
    }

    public void display() {
        display(this.head);
    }

    public void display(Node head) {
        if (head == null)
            return;
        head.display();
        display(head.get_next());
    }

    private Node copy_list(Node result, Node source) {
        if (source == null)
            return result;
        result = new Node(source);
        result.set_next(copy_list(result.get_next(), source.get_next()));
        return result;
    }

    public int total_matching(int to_compare) {
        if (head == null)
            return 0;
        return this.total_matching(head, to_compare);
    }

    private int total_matching(Node head, int to_compare) {
        if (head == null)
            return 0;
        if (head.is_match(to_compare))
            return total_matching(head.get_next(), to_compare) + 1;
        return total_matching(head.get_next(), to_compare);
    }

    public int copy_with_node(Linked_List to_copy) {
        if (to_copy.head == null)
            return 0;
        this.head = new Node(to_copy.head);
        return this.head.copy_with_node(to_copy.head.get_next()) + 1;
    }

    public void add_at_beginning(int to_add) {
        if (this.head == null) {
            this.head = new Node(to_add);
            return;
        }
        Node temp = this.head;
        this.head = new Node(to_add);
        this.head.set_next(temp);
    }

    public int reverse_list() {
        if (this.head == null)
            return 0;
        else if (head.get_next() == null) return 1;
        return reverse_list(head, head.get_next());
    }

    private int reverse_list(Node previous, Node current) {
        if (current.get_next() == null) {
            this.head = current;
            this.head.set_next(previous);
            return 1;
        }
        int count = reverse_list(current, current.get_next());
        current.set_next(previous);
        previous.set_next(null);
        return ++count;
    }

}
